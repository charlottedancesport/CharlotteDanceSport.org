// JavaScript Document
  $(document).ready( function () {
  	$(".day_tooltip").tooltip({
		effect: 'fade',
		fadeOutSpeed: 100,
		predelay: 400
	});
  });